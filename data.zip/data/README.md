## Format Structure of the QRCD Dataset 

The sample below has three JSON objects (**without preprocessing**), one of which is a *zero-answer* question.

**Note**: The **preprocessed** versions of the train/dev datsets have the start_char for each answer adjusted to cater for the white space introduced to embrace the full stops that separate the verses of the Qur'anic passages from which the answers are extracted.

```
{
  "pq_id": "38:41-44_105",
  "passage": "واذكر عبدنا أيوب إذ نادى ربه أني مسني الشيطان بنصب وعذاب. اركض برجلك هذا مغتسل بارد وشراب. ووهبنا له أهله ومثلهم معهم رحمة منا وذكرى لأولي الألباب. وخذ بيدك ضغثا فاضرب به ولا تحنث إنا وجدناه صابرا نعم العبد إنه أواب.",
  "surah": 38,
  "verses": "41-44",
  "question": "من هو النبي المعروف بالصبر؟",
  "answers": [
    {
      "text": "أيوب",
      "start_char": 12
    }
  ]
}
{
  "pq_id": "74:32-48_330",
  "passage": "كلا والقمر. والليل إذ أدبر. والصبح إذا أسفر. إنها لإحدى الكبر. نذيرا للبشر. لمن شاء منكم أن يتقدم أو يتأخر. كل نفس بما كسبت رهينة. إلا أصحاب اليمين. في جنات يتساءلون. عن المجرمين. ما سلككم في سقر. قالوا لم نك من المصلين. ولم نك نطعم المسكين. وكنا نخوض مع الخائضين. وكنا نكذب بيوم الدين. حتى أتانا اليقين. فما تنفعهم شفاعة الشافعين.",
  "surah": 74,
  "verses": "32-48",
  "question": "ما هي الدلائل التي تشير بأن الانسان مخير؟",
  "answers": [
    {
      "text": "لمن شاء منكم أن يتقدم أو يتأخر",
      "start_char": 76
    },
    {
      "text": "كل نفس بما كسبت رهينة",
      "start_char": 108
    } 
  ]
}
{
  "pq_id": "28:85-88_322",
  "passage": "إن الذي فرض عليك القرآن لرادك إلى معاد قل ربي أعلم من جاء بالهدى ومن هو في ضلال مبين. وما كنت ترجو أن يلقى إليك الكتاب إلا رحمة من ربك فلا تكونن ظهيرا للكافرين. ولا يصدنك عن آيات الله بعد إذ أنزلت إليك وادع إلى ربك ولا تكونن من المشركين. ولا تدع مع الله إلها آخر لا إله إلا هو كل شيء هالك إلا وجهه له الحكم وإليه ترجعون.",
  "surah": 28,
  "verses": "85-88",
  "question": "هل تدبر القرآن فرض؟",
  "answers": []
}

```

